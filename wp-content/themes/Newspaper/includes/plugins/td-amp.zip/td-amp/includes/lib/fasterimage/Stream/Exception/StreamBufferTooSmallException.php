<?php namespace WillWashburn\Stream\Exception;

/**
 * Class StreamBufferTooSmallException
 *
 * @package WillWashburn\Stream\Exception
 */
class StreamBufferTooSmallException extends \Exception {}